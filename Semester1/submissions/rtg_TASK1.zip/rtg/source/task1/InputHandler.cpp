


#include "InputHandler.h"


void InputHandler::keyDown(GL::platform::Key key)
{
}

void InputHandler::keyUp(GL::platform::Key key)
{
}

void InputHandler::buttonDown(GL::platform::Button button, int x, int y)
{
}

void InputHandler::buttonUp(GL::platform::Button button, int x, int y)
{
}

void InputHandler::mouseMove(int x, int y)
{
}

void InputHandler::mouseWheel(int delta)
{
}
