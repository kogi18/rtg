
#include "Renderer.h"
#include "iostream"
#include "fstream"
#include "framework\png.h"

class GLException : public std::exception
{
private:
	GLint error_code;

public:
	GLException(GLint error) : error_code(error) {}
	virtual const char* what() const noexcept
	{
		switch (error_code)
		{
		case (GL_INVALID_ENUM):
			return "Enumeration parameter is not a legal enumeration for that function.";
		case (GL_INVALID_VALUE):
			return "Illegal parameter value for that function.";
		case (GL_INVALID_OPERATION):
			return "This operation cannot be executed in the current state of OpenGL.";
		case (GL_STACK_OVERFLOW):
			return "Stack overflow occurred.";
		case (GL_STACK_UNDERFLOW):
			return "Stack underflow occurred.";
		case (GL_OUT_OF_MEMORY):
			return "Out of memory.";
		case (GL_INVALID_FRAMEBUFFER_OPERATION):
			return "Operation could not be performed in the current state of the frame buffer.";
		default:
			return "Unknown error! Please check error code!";
		}
	}
};

#ifdef _DEBUG
#define GL_SAFE_CALL(A) ([&]                \
{                                           \
	struct error_guard						\
	{                                       \
		~error_guard() noexcept(false)      \
		{                                   \
			GLenum error = glGetError();    \
			if (error != GL_NO_ERROR)       \
			{                               \
				GLException ex(error);      \
				std::cerr << ex.what();     \
				throw ex;                   \
			}                               \
		}                                   \
	} guard;                                \
	return A;                               \
}())

class ShaderException : public std::exception {
private: std::string log;
public: ShaderException(std::string&& log) : log(std::move(log)) {}
		virtual const char* what() const noexcept { return log.c_str(); }
};

void checkShader(const GLint shader) {
	GLint isCompiled; GL_SAFE_CALL(glGetShaderiv(shader, GL_COMPILE_STATUS, &isCompiled));
	if (isCompiled != GL_TRUE) {
		GLint log_length; GL_SAFE_CALL(glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &log_length));
		auto buffer = std::unique_ptr<char[]>(new char[log_length]); GL_SAFE_CALL(glGetShaderInfoLog(shader, log_length, &log_length, buffer.get()));
		ShaderException ex(std::string(buffer.get(), log_length - 1)); std::cerr << ex.what(); throw ex;
	}
}

#else
#define GL_SAFE_CALL(A) (A)
#endif

GLfloat LIGHT[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat *vertexList, *normalList, *textureList;

int totalVertexCount, totalVertexFloatCount, totalTextureUVFloatCount;

math::vector<int, 4U> OBJ_VI_UVI_NI_FI = math::vector<int,4U>(0,0,0,0);
math::vector<float,3U> OBJ_VERTICES[650];
math::vector<float, 3U> OBJ_NORMALS[650];
math::vector<float, 2U> OBJ_TEXUV[650];
math::vector<int, 3U> OBJ_TRIANGLE_VI[1000];
math::vector<int, 3U> OBJ_TRIANGLE_NI[1000];
math::vector<int, 3U> OBJ_TRIANGLE_TI[1000];

// Load image for texture
const char* textureOBJFile = "..\\assets\\cube.obj";
const char* texturePNGFile = "..\\assets\\Red-brick-wall.png";
//const char* texturePNGFile = "..\\assets\\smile.png";
//const char* textureOBJFile = "..\\assets\\desert.obj";
//const char* texturePNGFile = "..\\assets\\sand.png";
//const char* textureOBJFile = "..\\assets\\nukahedron.obj";
//const char* texturePNGFile = "..\\assets\\nukahedron_diffuse.png";
bool useRGBA = true;
//const char* textureOBJFile = "..\\assets\\vader.obj";
//const char* texturePNGFile = "..\\assets\\vader.png";
//bool useRGBA = false;
image<std::uint32_t> textureImage(PNG::loadImage2D(texturePNGFile));
std::tuple<int, int> textureDim = PNG::readImageSize(texturePNGFile);
int textureWidth = std::get<0>(textureDim), textureHeight = std::get<1>(textureDim);

const char* vertex_shader_src = R"""(
#version 330

layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 texUV;

out vec2 vertex_texture_UV;
out vec3 camera_direction;
out vec3 fresh_normal;

uniform mat4 Model;
uniform mat4 View;
uniform mat4 Projection;

void main(){
	gl_Position = View * Model * vec4(position.x, position.y, position.z, 1.0f);
	camera_direction = normalize(-1.0f * vec3(gl_Position));
	mat3 normalMatrix = mat3(transpose(inverse(View * Model)));
	fresh_normal = normalize(normalMatrix * normal);

	gl_Position = Projection * gl_Position;
	vertex_texture_UV = texUV;
}
)""";

 const char* fragment_shader_src = R"""(
#version 330

in vec2 vertex_texture_UV;
in vec3 camera_direction;  // same as direction to the light since the light is attached to the camera
in vec3 fresh_normal;

out vec4 fragment_color;

uniform sampler2D faceTex;
uniform float PI;
uniform vec4 LightRGB;

void main(){
//	fragment_color = texture(faceTex, vertex_texture_UV);
//	fragment_color = vec4(1.0f, 1.0f, 1.0f, 1.0f) / PI * LightRGB * max(dot(normalize(fresh_normal), normalize(camera_direction)), 0.0f);
	fragment_color = texture(faceTex, vertex_texture_UV) / PI * LightRGB * max(dot(normalize(fresh_normal), normalize(camera_direction)), 0.0f);
}
)""";

Renderer::Renderer(GL::platform::Window& window)
	: BasicRenderer(window, 3, 3)
{
	glClearColor(0.1f, 0.3f, 1.0f, 1.0f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);

	// load OBJ file
	char * line = new char[100], * token1, * token2, * token3;
	std::ifstream OBJ_FILE (textureOBJFile);
	while(!OBJ_FILE.eof()){
		OBJ_FILE.getline(line,100);
		if (std::strncmp(line, "v ", 2) == 0) {
			math::vector<float, 3U> tempV;
//			std::cout << line << std::endl;
			std::strtok(line, " ");	// remove the v
			tempV.x = atof(std::strtok(NULL, " ")); // get the X
			tempV.y = atof(std::strtok(NULL, " ")); // get the Y
			tempV.z = atof(std::strtok(NULL, " ")); // get the Z
			OBJ_VERTICES[OBJ_VI_UVI_NI_FI.x] = tempV;
			OBJ_VI_UVI_NI_FI.x += 1;
		}
		else if (std::strncmp(line, "vn", 2) == 0) {
			math::vector<float, 3U> tempN;
	//		std::cout << line << std::endl;
			std::strtok(line, " ");	// remove the vn
			tempN.x = atof(std::strtok(NULL, " ")); // get the X
			tempN.y = atof(std::strtok(NULL, " ")); // get the Y
			tempN.z = atof(std::strtok(NULL, " ")); // get the Z
			OBJ_NORMALS[OBJ_VI_UVI_NI_FI.z] = tempN;
			OBJ_VI_UVI_NI_FI.z += 1;
		}
		else if (std::strncmp(line, "vt", 2) == 0) {
			math::vector<float, 2U> tempT;
//			std::cout << line << std::endl;
			std::strtok(line, " ");	// remove the vt
			tempT.x = atof(std::strtok(NULL, " ")); // get the U
			tempT.y = atof(std::strtok(NULL, " ")); // get the V
			OBJ_TEXUV[OBJ_VI_UVI_NI_FI.y] = tempT;
			OBJ_VI_UVI_NI_FI.y += 1;
		}
		else if (std::strncmp(line, "f ", 2) == 0) {
			math::vector<int, 3U> tmp_TVI;
			math::vector<int, 3U> tmp_TNI;
			math::vector<int, 3U> tmp_TTI;

	//		std::cout << line << std::endl;
			std::strtok(line, " ");	// remove the f
			token1 = std::strtok(NULL, " "); // get 1st triplet of vertex/texture/normal
			token2 = std::strtok(NULL, " "); // get 2nd triplet of vertex/texture/normal
			token3 = std::strtok(NULL, " "); // get 3rd triplet of vertex/texture/normal

			tmp_TVI.x = atof(std::strtok(token1, "/")) - 1;	//save the vertex in the vertices
			tmp_TTI.x = atof(std::strtok(NULL, "/")) - 1;	//save the texture in the textures
			tmp_TNI.x = atof(std::strtok(NULL, "/")) - 1;	//save the normal in the normals

			tmp_TVI.y = atof(std::strtok(token2, "/")) - 1;	//save the vertex in the vertices
			tmp_TTI.y = atof(std::strtok(NULL, "/")) - 1;	//save the texture in the textures
			tmp_TNI.y = atof(std::strtok(NULL, "/")) - 1;	//save the normal in the normals

			tmp_TVI.z = atof(std::strtok(token3, "/")) - 1;	//save the vertex in the vertices
			tmp_TTI.z = atof(std::strtok(NULL, "/")) - 1;	//save the texture in the textures
			tmp_TNI.z = atof(std::strtok(NULL, "/")) - 1;	//save the normal in the normals

			OBJ_TRIANGLE_VI[OBJ_VI_UVI_NI_FI.w] = tmp_TVI;
			OBJ_TRIANGLE_NI[OBJ_VI_UVI_NI_FI.w] = tmp_TNI;
			OBJ_TRIANGLE_TI[OBJ_VI_UVI_NI_FI.w] = tmp_TTI;
			OBJ_VI_UVI_NI_FI.w += 1;
		}
	}
	OBJ_FILE.close();


	std::cout << OBJ_VI_UVI_NI_FI << std::endl;

	//Prepare the data in right format
	totalVertexCount = OBJ_VI_UVI_NI_FI.w * 3; // number of F definitions * 3 triangle vertecies
	totalVertexFloatCount = totalVertexCount * 3;  // number of F definitions * 3 triangle vertecies * 3 values for vertex
	totalTextureUVFloatCount = totalVertexCount * 2;  // number of F definitions * 3 triangle vertecies * 2 values for vertex
	vertexList = new GLfloat[totalVertexFloatCount];
	normalList = new GLfloat[totalVertexFloatCount];
	textureList = new GLfloat[totalTextureUVFloatCount];

	for (int triangle = 0, row; triangle < OBJ_VI_UVI_NI_FI.w; triangle++) {
		// row of the table if each row has the whole triangle
		row = triangle * 9;

		math::vector<int, 3U> triangleV = OBJ_TRIANGLE_VI[triangle];
		math::vector<int, 3U> triangleN = OBJ_TRIANGLE_NI[triangle];
		math::vector<int, 3U> triangleT = OBJ_TRIANGLE_TI[triangle];

		// load the 3 floats for each vertex
		vertexList[row] = OBJ_VERTICES[triangleV.x].x;
		vertexList[row + 1] = OBJ_VERTICES[triangleV.x].y;
		vertexList[row + 2] = OBJ_VERTICES[triangleV.x].z;
		// next vertex saved as Y
		vertexList[row + 3] = OBJ_VERTICES[triangleV.y].x;
		vertexList[row + 4] = OBJ_VERTICES[triangleV.y].y;
		vertexList[row + 5] = OBJ_VERTICES[triangleV.y].z;
		// next vertex saved as Z
		vertexList[row + 6] = OBJ_VERTICES[triangleV.z].x;
		vertexList[row + 7] = OBJ_VERTICES[triangleV.z].y;
		vertexList[row + 8] = OBJ_VERTICES[triangleV.z].z;

		// load the 3 floats for each normal
		normalList[row] = OBJ_NORMALS[triangleN.x].x;
		normalList[row + 1] = OBJ_NORMALS[triangleN.x].y;
		normalList[row + 2] = OBJ_NORMALS[triangleN.x].z;
		// next vertex saved as Y
		normalList[row + 3] = OBJ_NORMALS[triangleN.y].x;
		normalList[row + 4] = OBJ_NORMALS[triangleN.y].y;
		normalList[row + 5] = OBJ_NORMALS[triangleN.y].z;
		// next vertex saved as Z
		normalList[row + 6] = OBJ_NORMALS[triangleN.z].x;
		normalList[row + 7] = OBJ_NORMALS[triangleN.z].y;
		normalList[row + 8] = OBJ_NORMALS[triangleN.z].z;

		// row of the table if each row has the whole triangle UV
		row = triangle * 6;
		// load the 2 floats for each vertex
		textureList[row] = OBJ_TEXUV[triangleT.x].x;
		textureList[row + 1] = OBJ_TEXUV[triangleT.x].y;
		// next vertex saved as Y
		textureList[row + 2] = OBJ_TEXUV[triangleT.y].x;
		textureList[row + 3] = OBJ_TEXUV[triangleT.y].y;
		// next vertex saved as Z
		textureList[row + 4] = OBJ_TEXUV[triangleT.z].x;
		textureList[row + 5] = OBJ_TEXUV[triangleT.z].y;
	}

	window.attach(this);
}

void Renderer::resize(int width, int height)
{
	viewport_width = width;
	viewport_height = height;
}

float Renderer::deg2rad(float degrees) {
	return pi * degrees / 180.0f;
}

void Renderer::render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//addDegree = 0;
	glViewport(0, 0, viewport_width, viewport_height);
	// set the afine transformation vlaues
	float
		// object settings
		tX = 0.0f,
		tY = 0.0f,
		tZ = -1.0f,
		rotX = deg2rad(0.04f*addDegree),
		rotY = deg2rad(-0.08f*addDegree),
		rotZ = deg2rad(0.01f*addDegree),
		sX = 0.25f,
		sY = 0.25f,
		sZ = 0.25f,
		//camera settings
		cameraX = 0.0f,
		cameraY = 0.0f,
		cameraZ = 0.0f,
		lookAtX = tX,
		lookAtY = tY,
		lookAtZ = tZ,
		cameraUpX = 0.0f,
		cameraUpY = 1.0f,
		cameraUpZ = 0.0f,
		// projection settings
		nearFrame = 0.5f,
		farFrame = 5.0f,
		viewAngle = deg2rad(60);

	float sinX = sin(rotX), cosX = cos(rotX),
		sinY = sin(rotY), cosY = cos(rotY),
		sinZ = sin(rotZ), cosZ = cos(rotZ);

	// define the matrices
	math::float4x4 scaleM = math::float4x4(sX, 0, 0, 0, 0, sY, 0, 0, 0, 0, sZ, 0, 0, 0, 0, 1);
	math::float4x4 rotationXM = math::identity<math::float4x4>();
	math::float4x4 rotationYM = math::identity<math::float4x4>();
	math::float4x4 rotationZM = math::identity<math::float4x4>();

	rotationXM._22 = cosX;
	rotationXM._33 = cosX;
	rotationXM._23 = -sinX;
	rotationXM._32 = sinX;

	rotationYM._11 = cosY;
	rotationYM._33 = cosY;
	rotationYM._13 = sinY;
	rotationYM._31 = -sinY;

	rotationZM._11 = cosZ;
	rotationZM._22 = cosZ;
	rotationZM._12 = -sinZ;
	rotationZM._21 = sinZ;

	math::float4x4 modelM = rotationXM * rotationYM * rotationZM * scaleM;
	modelM._14 = tX;
	modelM._24 = tY;
	modelM._34 = tZ;

	//std::cout << modelM << "\n" << std::endl;

	GLfloat modelMGL[4][4] = {
		{ modelM._11, modelM._12, modelM._13, modelM._14 },
		{ modelM._21, modelM._22, modelM._23, modelM._24 },
		{ modelM._31, modelM._32, modelM._33, modelM._34 },
		{ modelM._41, modelM._42, modelM._43, modelM._44 }
	};

	// view matrix
	math::vector<float, 3U> cameraPos = math::vector<float, 3U>(cameraX, cameraY, cameraZ);
	math::vector<float, 3U> W = normalize(cameraPos - math::vector<float, 3U>(lookAtX, lookAtY, lookAtZ));
	math::vector<float, 3U> cameraUP = math::vector<float, 3U>(cameraUpX, cameraUpY, cameraUpZ);
	math::vector<float, 3U> U = normalize(cross(cameraUP, W));
	math::vector<float, 3U> V = cross(W, U);

	GLfloat viewMGL[4][4] = {
		{ U[0], U[1], U[2], -dot(cameraPos, U) },
		{ V[0], V[1], V[2], -dot(cameraPos, V) },
		{ W[0], W[1], W[2], -dot(cameraPos, W) },
		{ 0.0f, 0.0f, 0.0f, 1.0f }
	};

	// projection matrix
	float aspect = float(viewport_width) / float(viewport_height),
		tanFieldViewAngle = tan(viewAngle / 2.0f);
	GLfloat projectionMGL[4][4] = {
		{ 1.0f / (aspect * tanFieldViewAngle), 0.0f, 0.0f, 0.0f },
		{ 0.0f, 1.0f / tanFieldViewAngle,  0.0f, 0.0f },
		{ 0.0f, 0.0f, -(farFrame + nearFrame) / (farFrame - nearFrame), -(2 * farFrame * nearFrame) / (farFrame - nearFrame) },
		{ 0.0f, 0.0f, -1.0f, 0.0f }
	};

	// the VAO declaration and binding
	GLuint vao;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// create VOB to send vertex and color data
	GLuint vertexVOB, normalVOB, textUVVOB;
	// request names, bind for the 1st time, bind the actual data
	// the 4 * float count is since we have 32bit(4B) floats
	glGenBuffers(1, &vertexVOB);
	glBindBuffer(GL_ARRAY_BUFFER, vertexVOB);
	glBufferData(GL_ARRAY_BUFFER, 4 * totalVertexFloatCount, vertexList, GL_STATIC_DRAW);

	glGenBuffers(1, &normalVOB);
	glBindBuffer(GL_ARRAY_BUFFER, normalVOB);
	glBufferData(GL_ARRAY_BUFFER, 4 * totalVertexFloatCount, normalList, GL_STATIC_DRAW);

	glGenBuffers(1, &textUVVOB);
	glBindBuffer(GL_ARRAY_BUFFER, textUVVOB);
	glBufferData(GL_ARRAY_BUFFER, 4 * totalTextureUVFloatCount, textureList, GL_STATIC_DRAW);

	//configzre VAO layout
	// set position at 0
	glBindBuffer(GL_ARRAY_BUFFER, vertexVOB);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	// set normals at 1
	glBindBuffer(GL_ARRAY_BUFFER, normalVOB);
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);;
	// set textUV at 2
	glBindBuffer(GL_ARRAY_BUFFER, textUVVOB);
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
	// bind VAO
	glBindVertexArray(vao);

	// adding textures to the model
	GLuint texture;
	GL_SAFE_CALL(glGenTextures(1, &texture));
	GL_SAFE_CALL(glBindTexture(GL_TEXTURE_2D, texture));
	if (useRGBA == true) {
		GL_SAFE_CALL(glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, textureWidth, textureHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, data(textureImage)));
	}
	else {
		GL_SAFE_CALL(glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, textureWidth, textureHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, data(textureImage)));
	}
	GL_SAFE_CALL(glGenerateMipmap(GL_TEXTURE_2D));

	// create program to which we connect the shaders
	GLuint program = GL_SAFE_CALL(glCreateProgram());

	// load vertex shader
	GLuint vertexShader = GL_SAFE_CALL(glCreateShader(GL_VERTEX_SHADER));
	GL_SAFE_CALL(glShaderSource(vertexShader, 1, &vertex_shader_src, 0));
	GL_SAFE_CALL(glCompileShader(vertexShader));
	GL_SAFE_CALL(glAttachShader(program, vertexShader));

	// load fragment shader
	GLuint fragmentShader = GL_SAFE_CALL(glCreateShader(GL_FRAGMENT_SHADER));
	GL_SAFE_CALL(glShaderSource(fragmentShader, 1, &fragment_shader_src, 0));
	GL_SAFE_CALL(glCompileShader(fragmentShader));
	GL_SAFE_CALL(glAttachShader(program, fragmentShader));

	// link the program to the GPU
	GL_SAFE_CALL(glLinkProgram(program));

	// use the program
	glUseProgram(program);

	// link matrices to uniforms after load
	GLint modelUniform = GL_SAFE_CALL(glGetUniformLocation(program, "Model"));
	GL_SAFE_CALL(glUniformMatrix4fv(modelUniform, 1, GL_TRUE, *modelMGL));
	GLint viewUniform = GL_SAFE_CALL(glGetUniformLocation(program, "View"));
	GL_SAFE_CALL(glUniformMatrix4fv(viewUniform, 1, GL_TRUE, *viewMGL));
	GLint projectionUniform = GL_SAFE_CALL(glGetUniformLocation(program, "Projection"));
	GL_SAFE_CALL(glUniformMatrix4fv(projectionUniform, 1, GL_TRUE, *projectionMGL));
	// link uniform values to fragment shader
	GLint piUniform = GL_SAFE_CALL(glGetUniformLocation(program, "PI"));
	GL_SAFE_CALL(glUniform1f(piUniform, pi));
	GLint lightUniform = GL_SAFE_CALL(glGetUniformLocation(program, "LightRGB"));
	GL_SAFE_CALL(glUniform4f(lightUniform, LIGHT[0], LIGHT[1], LIGHT[2], LIGHT[3]));

	// start vertex shader to draw the triangles
	GL_SAFE_CALL(glDrawArrays(GL_TRIANGLES, 0, totalVertexCount));

	swapBuffers();
	addDegree++;
}